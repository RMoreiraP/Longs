#!/bin/bash

wd="$(pwd)"
inv="$1"
ind="HG001"
kmer_size="$2"
kmers_windows="$3"
error="$4"


## Coger la region y los nombres de los reads en reverse
#samtools view $initBam "region que queremos"
#samtools view -f 16 $initBam "region que queremos" | awk '{print $1}'

mkdir -p $inv
chr="$(grep "$inv[[:space:]]" $wd/../Infor/ListaRef_todos.txt | cut -f2 | sed 's/:/\t/g' | cut -f1)"
chr_name="$(cat $wd/../Infor/conversion.txt | grep $chr | cut -f1)"
pos=$(grep "$inv[[:space:]]" $wd/../Infor/ListaRef_todos.txt | cut -f2 | tr -d "[[:space:]]" | sed 's/:/\t/g' | cut -f2 | tr -d "[[:space:]]")
selInv=$chr_name:$pos

samtools faidx $wd/../Infor/Reference/Std_ref.fa "$selInv" > $wd/$inv/${inv}_ref.fa

jellyfish count -m $kmer_size -s 100M -C -c 1 -U 1 $wd/$inv/${inv}_ref.fa -o $wd/$inv/kmers_${inv}_ref.jf
jellyfish dump -c -t $wd/$inv/kmers_${inv}_ref.jf | awk '{{print $1}}' > $wd/$inv/kmers_${inv}_ref.db
awk '{{ print ">"$0"\n"$0 }}' $wd/$inv/kmers_${inv}_ref.db > $wd/$inv/kmers_${inv}_ref.fa

mrsfast --ws 14 --index $wd/$inv/${inv}_ref.fa
mrsfast --search $wd/$inv/${inv}_ref.fa --threads 8 --mem 16 --seq $wd/$inv/kmers_${inv}_ref.fa -o $wd/$inv/${inv}_map.sam --disable-nohits -e 0
samtools sort $wd/$inv/${inv}_map.sam -o $wd/$inv/${inv}_map.bam
 
bedtools bamtobed -i $wd/$inv/${inv}_map.bam > $wd/$inv/${inv}_map.bed
bedtools merge -i $wd/$inv/${inv}_map.bed > $wd/$inv/merge_${inv}_map.bed
bedtools intersect -a $wd/$inv/${inv}_map.bed -b $wd/$inv/merge_${inv}_map.bed -wo | cut -f 1,2,4,8 > $wd/$inv/${inv}_map.loc

groups="$(cat $wd/$inv/${inv}_map.loc | cut -f4 | uniq)"

> $wd/$inv/selected_kmers

for a in $groups
do
  size_group=$(cat $wd/$inv/${inv}_map.loc | awk -F '\t' -v group="$a" '$4 == group { print $2 }' | wc -l)
  
  if [ $size_group -le $kmer_size ];then
    cat $wd/$inv/${inv}_map.loc | awk -F '\t' -v group="$a" '$4 == group { print $3 }' | head -1 >> $wd/$inv/selected_kmers
  elif [ $size_group -le $kmers_windows ];then
    cat $wd/$inv/${inv}_map.loc | awk -F '\t' -v group="$a" '$4 == group { print $3 }' | head -1 >> $wd/$inv/selected_kmers
    cat $wd/$inv/${inv}_map.loc | awk -F '\t' -v group="$a" '$4 == group { print $3 }' | tail -1 >> $wd/$inv/selected_kmers
  else
    count=$((size_group + kmers_windows))
    line_numbers="$(cat $wd/$inv/${inv}_map.loc | awk -F '\t' -v group="$a" '$4 == group { print $3 }')"
    indices=$(seq 1 "$kmers_windows" "$count")

    for index in $indices; do
        start_line=$index
        cat "$wd/$inv/${inv}_map.loc" | awk -F '\t' -v group="$a" '$4 == group { print $3 }' | head -n "$start_line" | tail -1 >> $wd/$inv/selected_kmers
    done
  fi
done

grep -f $wd/$inv/selected_kmers $wd/$inv/kmers_${inv}_ref.fa > $wd/$inv/${inv}_kmers.fa

cat $wd/$inv/${inv}_ref.fa $wd/$inv/${ind}.fa > $wd/$inv/${inv}_${ind}.fa

mrsfast --ws 14 --index $wd/$inv/${inv}_${ind}.fa
mrsfast --search $wd/$inv/${inv}_${ind}.fa --threads 8 --mem 16 --seq $wd/$inv/${inv}_kmers.fa -o $wd/$inv/${inv}_${ind}.sam --disable-nohits -e $error
samtools sort $wd/$inv/${inv}_${ind}.sam -o $wd/$inv/${inv}_${ind}.bam
bedtools bamtobed -i $wd/$inv/${inv}_${ind}.bam > $wd/$inv/${inv}_${ind}.bed