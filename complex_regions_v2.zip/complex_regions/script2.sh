#!/bin/bash

wd="$(pwd)"
inv="$1"
ind="HG001"
kmer_size=25
kmers_windows=1000

a="0"


count=$(cat $wd/$inv/${inv}_map.loc | awk -F '\t' -v group="$a" '$4 == group { print $2 }' | wc -l)
size_group=$((count + kmers_windows))
line_numbers="$(cat $wd/$inv/${inv}_map.loc | awk -F '\t' -v group="$a" '$4 == group { print $3 }')"

indices=$(seq 1 "$kmers_windows" "$size_group")
echo $indices

for index in $indices; do
    start_line=$index

    cat "$wd/$inv/${inv}_map.loc" | awk -F '\t' -v group="$a" '$4 == group { print $3 }' | head -n "$start_line" | tail -1 >> "$wd/$inv/sel_kmers"
done
    

