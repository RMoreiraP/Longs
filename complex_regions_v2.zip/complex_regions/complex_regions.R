library(readr)
library(ggplot2)
library(dplyr)
library(tidyverse)
library(igraph)

umbral <- 25
minim_kmer <- 1
minor_diff <- 0.95
primer_read <- "chr16:75198160-75230127"

min_val_col <- minim_kmer*2 + 1

# Upload bed information and negative strand information
reads_bed <- read_tsv("complex_regions/hsinv0030_hg001_kmer30_e0.bed", col_names = c("Read_name", "start", "end", "kmer_name", "score", "strand"))
reverse_reads <- read.table("complex_regions/reverse_reads.txt")
colnames(reverse_reads) <- c("Names")

change_sup <- intersect(reads_bed$Read_name, reverse_reads$Names)

for (row_change in change_sup) {
  rows_to_change <- which(reads_bed$Read_name == row_change)
  for (row in rows_to_change) {
    current_strand <- reads_bed$strand[row]
    reads_bed$strand[row] <- ifelse(current_strand == "+", "-", ifelse(current_strand == "-", "+", current_strand))
  }
}

### Conversion of bed format into a dataframe with start,end and strand  
reads_bed_filt1 <- reads_bed[,c(1,2,3,4)]

pivoted_start_end <- reads_bed_filt1 %>%
  pivot_longer(cols = c(start, end), 
               names_to = "position_type", 
               values_to = "position_value") %>%
  unite("kmer_position", kmer_name, position_type, sep = "_") %>%
  pivot_wider(names_from = kmer_position, values_from = position_value)

reads_bed_filt2 <- reads_bed[,c(1,4,6)]

pivoted_strand <- reads_bed_filt2 %>%
  pivot_longer(cols = c(strand), 
               names_to = "position_type", 
               values_to = "position_value") %>%
  unite("kmer_position", kmer_name, position_type, sep = "_") %>%
  pivot_wider(names_from = kmer_position, values_from = position_value)

final_result <- left_join(pivoted_start_end, pivoted_strand, by = "Read_name")
final_result <- final_result %>% column_to_rownames(var = "Read_name")

colnames <- colnames(final_result)[-1]

### Selection of cells with only one value
get_unique_position <- function(column) {
  column <- gsub("[^0-9+,\\-]", "", as.character(column))
  positions <- unlist(strsplit(column, ","))
  unique_positions <- unique(positions)
  if (length(positions) == 1){
    if (length(unique_positions) == 1) {
      
      if (unique_positions %in% c("+", "-")) {
        return(unique_positions)
      } else {
        return(as.numeric(unique_positions))
      }
    } else {
      return(NA)
    }
  } else {
    return(NA)
  }
}

rownames <- rownames(final_result)

unique_positions <- as.data.frame(lapply(final_result, function(col) sapply(col, get_unique_position)))
rownames(unique_positions) <- rownames

### Mean between start and end kmer position
start_columns <- grep("_start$", colnames(unique_positions), value = TRUE)
end_columns <- grep("_end$", colnames(unique_positions), value = TRUE)
strand_columns <- grep("_strand$", colnames(unique_positions), value = TRUE)

final_result_processed <- data.frame(Read_name = rownames(unique_positions))

for (i in seq_along(start_columns)) {
  kmer_start_col <- start_columns[i]
  kmer_end_col <- end_columns[i]
  kmer_strand_col <- strand_columns[i]
  
  kmer_name <- sub("_start$", "", start_columns[i])
  
  unique_positions[[kmer_start_col]] <- as.numeric(unique_positions[[kmer_start_col]])
  unique_positions[[kmer_end_col]] <- as.numeric(unique_positions[[kmer_end_col]])
  
  final_result_processed[[paste0(kmer_name, "_position")]] <- (unique_positions[[kmer_start_col]] + unique_positions[[kmer_end_col]]) / 2
  final_result_processed[[paste0(kmer_name, "_strand")]] <- unique_positions[[kmer_strand_col]]
}

final_result_processed[sapply(final_result_processed, is.null)] <- NA

### Calculation of percentatge of probes present and filtering those under the threshold
porcentaje_na <- rowMeans(!is.na(final_result_processed)) * 100
min_kmer <- rowSums(!is.na(final_result_processed))

final_result_review <- final_result_processed[porcentaje_na > umbral, ]
#final_result_review <- final_result_review[min_kmer > min_val_col, ]

### Convert rest of reads based on reference

convert_to_relative_distances1 <- function(final_result_review, primer_read, reverse_reads) {
  position_cols <- grep("position$", colnames(final_result_review), value = TRUE)
  
  for (i in 1:nrow(final_result_review)) {
    row_values <- as.numeric(final_result_review[i, position_cols])
    min_valid_value <- min(row_values, na.rm = TRUE)
    
    if (!is.na(min_valid_value)) {
      min_valid_index <- which(row_values == min_valid_value)[1]
      reference_value <- as.numeric(final_result_review[primer_read, position_cols[min_valid_index]])
      
      if (!is.na(reference_value)) {
        adjustment_value <- abs(min_valid_value - reference_value)
        print(adjustment_value)
        current_name <- final_result_review[i, "Read_name"]
        
        if (current_name %in% reverse_reads$Names) {
          row_values <- ifelse(!is.na(row_values), abs(row_values - adjustment_value), row_values)
        } else {
          row_values <- ifelse(!is.na(row_values), abs(row_values + adjustment_value), row_values)
        }
      }
      
      final_result_review[i, position_cols] <- row_values
    }
  }
  
  return(final_result_review)
}

reads_bed_relative <- convert_to_relative_distances1(final_result_review, primer_read = 1, reverse_reads)


Vale este codigo es correcto pero no hace lo que quiero, si te fijas aquí establece un valor por cada row name llamado adjutment_value y em calcula por cada valor de row_values pues la resta o la suma en función de otra cosa. Sin embargo no es lo que quiero exactamente, yo lo que busco que me haga es primero que me busque el valor más pequeño y le asigne allí el valor que hay en el primer read para ese. Hasta aquí creo q es correcto lo que hace. Despues lo que quiero es que calcula por cada read la diferencia que hay entre el primer kmero comun y el siguiente kmero, el resultado de ahí se utilizara en el siguiente calculo. Te pongo un ejemplo porque creo que no se ha entendido:
  
  Nosotros tenemos en el dataframe el primer read con estos valores:
  
  15 2054 3080 5085

Y en siguiente read seria:
  
  45057 47094 48111

Entonces se tendria que el valor más pequeño del read convertirlo en 15 y despues hacer 15+(47094-45057), esto te saldria 2052. Entonces seria 2052 +(48111-47094) y asi succesivamente. Hay algo que no haya quedado claro?
  ChatGPT
Entiendo que quieres ajustar los valores de las posiciones relativas en función del valor mínimo y luego calcular las diferencias acumulativas entre los valores de las posiciones de cada read. Aquí está una versión modificada del código que debería hacer lo que describes:
  
  r
Copiar código
convert_to_relative_distances2 <- function(final_result_review, primer_read, reverse_reads) {
  position_cols <- grep("position$", colnames(final_result_review), value = TRUE)
  
  for (i in 1:nrow(final_result_review)) {
    row_values <- as.numeric(final_result_review[i, position_cols])
    min_valid_value <- min(row_values, na.rm = TRUE)
    
    if (!is.na(min_valid_value)) {
      min_valid_index <- which(row_values == min_valid_value)[1]
      reference_value <- as.numeric(final_result_review[primer_read, position_cols[min_valid_index]])
      
      if (!is.na(reference_value)) {
        # Set the minimum value to the reference value from the primer read
        adjustment_value <- reference_value - min_valid_value
        row_values <- row_values + adjustment_value
        
        # Calculate the cumulative differences
        for (j in 2:length(row_values)) {
          row_values[j] <- row_values[j-1] + (row_values[j] - row_values[j-1])
        }
      }
      
      final_result_review[i, position_cols] <- row_values
    }
  }
  
  return(final_result_review)
}

# Suponiendo que reverse_reads es un data frame con una columna 'Names'
reverse_reads <- data.frame(Names = c("read2", "read4")) # Ejemplo

reads_bed_relative <- convert_to_relative_distances2(final_result_review, primer_read = 1, reverse_reads = reverse_reads)
Explicación:
  Identificación del valor mínimo: Se busca el valor mínimo de las posiciones dentro de cada read.
Ajuste basado en el primer_read: Se ajusta el valor mínimo de cada read al valor correspondiente del primer_read.
Cálculo de diferencias acumulativas: Se calculan las diferencias acumulativas para las posiciones del read ajustado.
Consideraciones adicionales:
  Si necesitas ajustar de manera diferente los reverse_reads, puedes incluir una lógica específica en el bucle interno donde se calculan las diferencias acumulativas.
Asegúrate de que las columnas de posiciones están correctamente identificadas con grep("position$", colnames(final_result_review), value = TRUE).
Espero que esto resuelva tu problema y realice las operaciones como esperas. Si necesitas más ajustes, por favor, házmelo saber.

Aquí esta fallando algo:
  
  convert_to_relative_distances2 <- function(final_result_review, primer_read, reverse_reads) {
    position_cols <- grep("position$", colnames(final_result_review), value = TRUE)
    
    for (i in 1:nrow(final_result_review)) {
      row_values <- as.numeric(final_result_review[i, position_cols])
      min_valid_value <- min(row_values, na.rm = TRUE)
      
      if (!is.na(min_valid_value)) {
        min_valid_index <- which(row_values == min_valid_value)[1]
        reference_value <- as.numeric(final_result_review[primer_read, position_cols[min_valid_index]])
        
        if (!is.na(reference_value)) {
          adjustment_value <- reference_value - min_valid_value
          row_values <- row_values + adjustment_value
          current_name <- final_result_review[i, "Read_name"]
          
          if (current_name %in% reverse_reads$Names) {
            for (j in 2:length(row_values)) {
              row_values[j] <- row_values[j-1] - (row_values[j] - row_values[j-1])
            }
          } else {
            for (j in 2:length(row_values)) {
              row_values[j] <- row_values[j-1] + (row_values[j] - row_values[j-1])
            }
          }
        }
        
        final_result_review[i, position_cols] <- row_values
      }
    }
    
    return(final_result_review)
  }

reads_bed_relative <- convert_to_relative_distances2(final_result_review, primer_read = 1, reverse_reads = reverse_reads)


Ya que me estan saliendo solo el primer valor pero els resto de celdas me sale NA.
ChatGPT
Entiendo el problema, parece que hay un malentendido en la lógica de cálculo de las diferencias acumulativas. Vamos a corregirlo para asegurarnos de que estamos calculando correctamente las diferencias entre los valores consecutivos y acumulándolos.

Aquí está la función corregida:
  
  r
Copiar código
convert_to_relative_distances2 <- function(final_result_review, primer_read, reverse_reads) {
  position_cols <- grep("position$", colnames(final_result_review), value = TRUE)
  
  for (i in 1:nrow(final_result_review)) {
    row_values <- as.numeric(final_result_review[i, position_cols])
    min_valid_value <- min(row_values, na.rm = TRUE)
    
    if (!is.na(min_valid_value)) {
      min_valid_index <- which(row_values == min_valid_value)[1]
      reference_value <- as.numeric(final_result_review[primer_read, position_cols[min_valid_index]])
      
      if (!is.na(reference_value)) {
        adjustment_value <- reference_value - min_valid_value
        row_values <- row_values + adjustment_value
        current_name <- final_result_review[i, "Read_name"]
        
        if (current_name %in% reverse_reads$Names) {
          for (j in 2:length(row_values)) {
            row_values[j] <- row_values[j-1] - (row_values[j] - row_values[j-1])
          }
        } else {
          for (j in 2:length(row_values)) {
            row_values[j] <- row_values[j-1] + (row_values[j] - row_values[j-1])
          }
        }
      }
      
      final_result_review[i, position_cols] <- row_values
    }
  }
  
  return(final_result_review)
}

# Ejemplo de uso (asegúrate de definir `final_result_review` y `reverse_reads`)
# reads_bed_relative <- convert_to_relative_distances2(final_result_review, primer_read = 1, reverse_reads = reverse_reads)

convert_to_relative_distances2 <- function(final_result_review, primer_read, reverse_reads) {
  position_cols <- grep("position$", colnames(final_result_review), value = TRUE)
  
  for (i in 1:nrow(final_result_review)) {
    row_values <- as.numeric(final_result_review[i, position_cols])
    min_valid_value <- min(row_values, na.rm = TRUE)
    
    if (!is.na(min_valid_value)) {
      min_valid_index <- which(row_values == min_valid_value)[1]
      reference_value <- as.numeric(final_result_review[primer_read, position_cols[min_valid_index]])
      
      if (!is.na(reference_value)) {
        # Ajuste del valor mínimo al valor correspondiente en el primer read
        row_values[min_valid_index] <- reference_value
        current_name <- final_result_review[i, "Read_name"]
        
        if (current_name %in% reverse_reads$Names) {
          for (j in (min_valid_index + 1):length(row_values)) {
            if (!is.na(row_values[j])) {
              row_values[j] <- row_values[j-1] - (row_values[j] - row_values[j-1])
            }
          }
        } else {
          for (j in (min_valid_index + 1):length(row_values)) {
            if (!is.na(row_values[j])) {
              row_values[j] <- row_values[j-1] + (row_values[j] - row_values[j-1])
            }
          }
        }
      }
      
      final_result_review[i, position_cols] <- row_values
    }
  }
  
  return(final_result_review)
}

reads_bed_relative <- convert_to_relative_distances2(final_result_review, primer_read = 1, reverse_reads = reverse_reads)

write.table(final_result_review, "complex_regions/bed_hg30_hg001.txt")
### Conversion of absolute position by read into absolute by read, and calculation of the distances
convert_to_relative_distances <- function(final_result_review) {
  position_cols <- grep("position$", colnames(final_result_review), value = TRUE)
  
  for (i in 1:nrow(final_result_review)) {
    row_values <- final_result_review[i, position_cols]
    min_valid_value <- min(row_values, na.rm = TRUE)
    
    if (!is.na(min_valid_value)) {
      row_values <- ifelse(!is.na(row_values), row_values - min_valid_value, row_values)
      final_result_review[i, position_cols] <- row_values
    }
  }
  
  return(final_result_review)
}

reads_bed_relative <- convert_to_relative_distances(final_result_review)

position_cols <- grep("position$", colnames(reads_bed_relative), value = TRUE)
strand_cols <- grep("strand$", colnames(reads_bed_relative), value = TRUE)

### Convert adjust of 0 into real adjust for first kmer
start_pos <- final_result_review[final_result_review$Read_name == primer_read, 2]

row_index <- which(final_result_review$Read_name == primer_read)

for (col in position_cols) {
  reads_bed_relative[row_index, col] <- reads_bed_relative[row_index, col] + start_pos
}

### Unification of the strand of the reference, conversion all into +
unify_strands <- function(reads_bed_relative, ref_column) {
  strand_cols <- grep("_strand$", colnames(reads_bed_relative), value = TRUE)
  
  ref_row <- reads_bed_relative[1, strand_cols, drop = FALSE]
  flip_sign <- ref_row == "-"
 
  for (col in strand_cols) {
    for (i in 1:nrow(reads_bed_relative)) {
      if (!is.na(reads_bed_relative[i, col])) {
        if (!is.na(flip_sign[1, col]) && flip_sign[1, col]) {
          reads_bed_relative[i, col] <- ifelse(reads_bed_relative[i, col] == "-", "+", "-")
        }
      }
    }
  }
  
  return(reads_bed_relative)
}

reads_bed_relative <- unify_strands(reads_bed_relative, primer_read)

numeric_column <- sapply(names(reads_bed_relative), function(col) {
  is.numeric(reads_bed_relative[[col]]) && grepl("_position$", col)
})

numeric_position <- reads_bed_relative[, numeric_column]
rownames <- reads_bed_relative$Read_name

### Checking the reads which with coherent distances and remove those no coherent
results <- data.frame(
  fila = rownames,
  perc_pos = 0,
  perc_neg = 0,
  kmer_name_positive = "",
  kmer_name_negative = "",
  stringsAsFactors = FALSE
)

results$positive <- apply(numeric_position, 1, function(row) sum(row > 0, na.rm = TRUE))
results$negative <- apply(numeric_position, 1, function(row) sum(row < 0, na.rm = TRUE))
total_no_na <- apply(numeric_position, 1, function(row) sum(!is.na(row) & row != 0))

results$perc_pos <-  results$positive/total_no_na * 100
results$perc_neg <-  results$negative/total_no_na * 100

results$kmer_name_positive[is.na(results$kmer_name_positive)] <- ""
results$kmer_name_negative[is.na(results$kmer_name_negative)] <- ""

results$kmer_name_positive <- as.character(results$kmer_name_positive)
results$kmer_name_negative <- as.character(results$kmer_name_negative)

results$kmer_name_positive <- sapply(1:nrow(numeric_position), function(i) {
  paste(names(numeric_position)[which(numeric_position[i, ] > 0)], collapse = ",")
})

results$kmer_name_negative <- sapply(1:nrow(numeric_position), function(i) {
  paste(names(numeric_position)[which(numeric_position[i, ] < 0)], collapse = ",")
})

# for (i in 1:nrow(results)) {
#   kmer_cols <- c()
# 
#   if (results$perc_pos[i] < 50 && results$perc_pos[i] != 0) {
#     kmer_cols <- strsplit(results$kmer_name_positive[i], split = ",")[[1]]
#   } else if (results$perc_neg[i] < 50 && results$perc_pos[i] != 0){
#     kmer_cols <- strsplit(results$kmer_name_negative[i], split = ",")[[1]]
#   }
# 
#   read_name <- results$fila[i]
# 
#   if (read_name %in% reads_bed_relative$Read_name) {
#     for (col in kmer_cols) {
#       if (col %in% names(reads_bed_relative)) {
#         reads_bed_relative[reads_bed_relative$Read_name == read_name, col] <- NA
#         if (grepl("position", col)) {
#           new_col_name <- gsub("position", "strand", col)
#           reads_bed_relative[reads_bed_relative$Read_name == read_name, new_col_name] <- NA
#         }
#       }
#     }
#   }
# }

### Convert rest of reads based on reference
convert_to_relative_distances1 <- function(reads_bed_relative, primer_read) {
  position_cols <- grep("position$", colnames(reads_bed_relative), value = TRUE)
  
  for (i in 1:nrow(reads_bed_relative)) {
    row_values <- as.numeric(reads_bed_relative[i, position_cols])
    min_valid_value <- min(row_values, na.rm = TRUE)
    
    if (!is.na(min_valid_value)) {
      min_valid_index <- which(row_values == min_valid_value)[1]
      reference_value <- as.numeric(reads_bed_relative[primer_read, position_cols[min_valid_index]])
      
      if (!is.na(reference_value)) {
        adjustment_value <- min_valid_value - reference_value
        row_values <- ifelse(!is.na(row_values), abs(row_values - adjustment_value), row_values)
      }
      reads_bed_relative[i, position_cols] <- row_values
    }
  }
  
  return(reads_bed_relative)
}

reads_bed_relative <- convert_to_relative_distances1(reads_bed_relative, primer_read = 1)

### Change orientation of complete reverse reads
rows_to_change <- which(rowSums(reads_bed_relative[strand_cols] != "-", na.rm = TRUE) == 0)

for (row_strand_change in rows_to_change) {
  non_na_indices <- !is.na(reads_bed_relative[row_strand_change, strand_cols])
  reads_bed_relative[row_strand_change, strand_cols][non_na_indices] <- "+"
}

### Change + and - into 0 and 1
reads_bed_relative[, strand_cols] <- ifelse(reads_bed_relative[, strand_cols] == "+", 1, 0)

### Removing reference read
#reads_bed_relative <- reads_bed_relative[reads_bed_relative$Read_name != primer_read, ]


### Creation of a similarity matrix
calculate_similarity <- function(positions_i, positions_j, strands_i, strands_j, tolerance_percent) {
  position_similarity <- numeric(length(positions_i))
  strand_similarity <- numeric(length(strands_i))
  
  for (k in 1:length(positions_i)) {
    if (is.na(positions_i[k]) || is.na(positions_j[k])) {
      position_similarity[k] <- NA
    } else {
      if (positions_i[k] < positions_j[k]){
        difference <- (positions_i[k]/positions_j[k])
      } else if (positions_i[k] > positions_j[k]) {
        difference <- (positions_j[k]/positions_i[k])
      } else {
        difference <- 1
      }
      
      print(difference)
      
      if (difference >= minor_diff) {
        position_similarity[k] <- 1
      } else {
        position_similarity[k] <- 0
      }
    }
  }
  
  for (k in 1:length(strands_i)) {
    if (is.na(strands_i[k]) || is.na(strands_j[k])) {
      strand_similarity[k] <- NA
    } else {
      if (strands_i[k] == strands_j[k]){
        strand_similarity[k] <- 1
      } else {
        strand_similarity[k] <- 0
      }
    }
  }

  combined_similarity <- c(position_similarity, strand_similarity)
  
  similarity <- mean(combined_similarity, na.rm = TRUE)
  
  if (is.na(similarity)){
    similarity <- 0
  }
  return(similarity)
}

num_reads <- nrow(reads_bed_relative)
similarity_matrix <- matrix(0, nrow = num_reads, ncol = num_reads)

for (i in 1:(num_reads - 1)) {
  for (j in (i + 1):num_reads) {
    positions_i <- as.numeric(reads_bed_relative[i, position_cols])
    positions_j <- as.numeric(reads_bed_relative[j, position_cols])
    strands_i <- as.numeric(reads_bed_relative[i, strand_cols])
    strands_j <- as.numeric(reads_bed_relative[j, strand_cols])
    
    similarity <- calculate_similarity(positions_i, positions_j, strands_i, strands_j, tolerance_percent)
    
    similarity_matrix[i, j] <- similarity
    similarity_matrix[j, i] <- similarity
  }
}

read_names <- reads_bed_relative$Read_name

rownames(similarity_matrix) <- read_names
colnames(similarity_matrix) <- read_names


### Representation of similarity matrix with hclust
distance_matrix <- as.dist(1 - similarity_matrix)

hc <- hclust(distance_matrix, method="average")
plot(hc, xlab="Reads", sub="", cex=0.4)
clusters <- cutree(hc, k=2, h = 0.5)










##### Representation test
reads_bed_relative <- reads_bed_relative %>%
  mutate(across(matches("_position$"), as.numeric))

cols_position <- grep("_position$", colnames(reads_bed_relative), value = TRUE)
cols_strand <- grep("_strand$", colnames(reads_bed_relative), value = TRUE)

# Convertimos a formato largo
data_long <- reads_bed_relative %>%
  pivot_longer(cols = all_of(c(cols_position, cols_strand)),
               names_to = c("type", ".value"),
               names_pattern = "(.*)_(.*)") %>%
  arrange(Read_name)

data_long <- data_long[data_long$Read_name %in% c("71be2041-c07b-4807-90b0-6772b64cd724","2f43a34e-b750-4db2-a32b-8e2214cb775c", primer_read), ]

ordenar <- c(primer_read, "aef6d3d2-d43c-44ff-85ce-d1f7d7f8ff3c", "650eb0e6-c10d-4e56-b418-def6678ed3d6", "71be2041-c07b-4807-90b0-6772b64cd724","2f43a34e-b750-4db2-a32b-8e2214cb775c")

data_long <- data_long %>%
  mutate(Read_name = factor(Read_name, levels = ordenar)) %>%
  arrange(Read_name, position)

# Crear un data frame para los segmentos
segments <- data_long %>%
  group_by(type) %>%
  mutate(next_Read_name = lead(Read_name),
         next_position = lead(position)) %>%
  filter(!is.na(next_position) & next_Read_name != Read_name) %>%
  ungroup() %>%
  mutate(next_Read_name = factor(next_Read_name, levels = ordenar))

# Crear el gráfico
g <- ggplot(data_long, aes(x = position, y = factor(Read_name, levels = ordenar))) +
  geom_line(aes(group = type)) + 
  geom_point(aes(color = strand), size = 3, show.legend = FALSE) +
  labs(x = "Position", y = "read_id Name", color = "Strand") +
  theme_minimal() +
  theme(axis.text.y = element_text(size = 8))
ggsave("complex_regions/example_pres_corrected.jpg", g, width = 10, height = 6)


unic <- unique(data_long$Read_name)
he <- head(unic, 20)
data_long <- data_long[data_long$Read_name %in% he, ]

a <- ggplot(data_long, aes(x = position, y = Read_name)) +
         geom_point(aes(color = strand), size=0.5, show.legend = FALSE) +
  geom_line(aes(group = type)) + 
ggsave("complex_regions/x.jpg", a, width = 10, height = 6)

data_long_filtered <- data_long[!is.na(data_long$position), ]

segments <- data_long_filtered %>%
  group_by(type) %>%
  mutate(next_Read_name = lead(Read_name),
         next_position = lead(position)) %>%
  filter(!is.na(next_position) & next_Read_name != Read_name) %>%
  ungroup()


a <- ggplot(data_long_filtered, aes(x = position, y = Read_name)) +
  geom_point(aes(color = strand), size=0.5, show.legend = FALSE) +
  geom_segment(data = segments, aes(x = position, xend = next_position, 
                                    y = factor(Read_name, levels = order(data_long_filtered$Read_name)), 
                                    yend = factor(next_Read_name, levels = order(data_long_filtered$Read_name)),
                                    group = type), linewidth = 1) +
  theme_minimal()  # Añadir un tema para mejorar la apariencia del gráfico
ggsave("complex_regions/x.jpg", a, width = 10, height = 6)
